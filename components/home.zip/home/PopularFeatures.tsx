/**
 * PopularFeatures - Main component for popular movies section
 * Displays Douban movie recommendations with tag filtering and infinite scroll.
 * Includes personalized "为你推荐" tag when user has 2+ watched items.
 */

'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { TagManager } from './TagManager';
import { MovieGrid } from './MovieGrid';
import { useTagManager } from './hooks/useTagManager';
import { usePopularMovies } from './hooks/usePopularMovies';
import { usePersonalizedRecommendations } from './hooks/usePersonalizedRecommendations';

interface DoubanMovie {
  id: string;
  title: string;
  cover: string;
  rate: string;
  url: string;
}

interface PopularFeaturesProps {
  onSearch?: (query: string) => void;
}

/** 滑出层是纯展示副本，滚动观察器用不到，给个空 ref 占位 */
const EMPTY_REF: React.RefObject<HTMLDivElement | null> = { current: null };

type CardDirection = 'forward' | 'back';

export function PopularFeatures({ onSearch }: PopularFeaturesProps) {
  const {
    tags,
    selectedTag,
    contentType,
    newTagInput,
    showTagManager,
    justAddedTag,
    setContentType,
    setSelectedTag,
    setNewTagInput,
    setShowTagManager,
    setJustAddedTag,
    handleAddTag,
    handleDeleteTag,
    handleRestoreDefaults,
    handleDragEnd,
    isLoadingTags,
  } = useTagManager();

  const router = useRouter();

  const {
    movies: recommendMovies,
    loading: recommendLoading,
    hasMore: recommendHasMore,
    hasHistory,
    prefetchRef: recommendPrefetchRef,
    loadMoreRef: recommendLoadMoreRef,
  } = usePersonalizedRecommendations(false);

  const [isRecommendSelected, setIsRecommendSelected] = useState(false);

  const effectiveRecommendSelected = hasHistory && isRecommendSelected;
  const isTagManagementMode = showTagManager;

  const {
    movies,
    loading,
    hasMore,
    prefetchRef,
    loadMoreRef,
  } = usePopularMovies(
    effectiveRecommendSelected ? '' : selectedTag,
    tags,
    contentType
  );

  // ── 电影 / 电视剧切换：下方卡片整体横向滑动 ──────────────────
  const [outgoingCards, setOutgoingCards] = useState<{
    movies: DoubanMovie[];
    direction: CardDirection;
  } | null>(null);
  const [enterDirection, setEnterDirection] = useState<CardDirection | null>(null);
  const previousTypeRef = useRef(contentType);

  // 这里拿到的 movies 仍是「切换前」那一组：
  // usePopularMovies 的清空动作在其内部 effect 中排队，下一次渲染才生效。
  // 切换是外部 store 驱动的，必须在这一刻把旧卡片存成快照，故此处有意同步 setState。
  /* eslint-disable react-hooks/set-state-in-effect */
  useEffect(() => {
    const previousType = previousTypeRef.current;
    if (previousType === contentType) return;
    previousTypeRef.current = contentType;

    const direction: CardDirection = contentType === 'tv' ? 'forward' : 'back';
    setEnterDirection(direction);

    if (movies.length > 0) {
      // 先原地保留旧卡片，等新数据到位时再一起滑动，中间不会露出空白
      setOutgoingCards({ movies, direction });
    }
  }, [contentType]); // eslint-disable-line react-hooks/exhaustive-deps
  /* eslint-enable react-hooks/set-state-in-effect */

  // 等新数据到位再滑入，否则滑进来的会是空白
  const isEntering = enterDirection !== null && !loading;

  useEffect(() => {
    if (!isEntering) return;
    const timer = window.setTimeout(() => {
      setEnterDirection(null);
      setOutgoingCards(null);
    }, 320);
    return () => window.clearTimeout(timer);
  }, [isEntering]);

  const enterClass = !isEntering
    ? ''
    : enterDirection === 'forward'
      ? 'kv-cards-enter-forward'
      : 'kv-cards-enter-back';

  const handleMovieClick = (movie: DoubanMovie) => {
    if (onSearch) {
      onSearch(movie.title);
    }
  };

  const handleRecommendSelect = () => {
    setIsRecommendSelected(true);
  };

  const handleRegularTagSelect = (tagId: string) => {
    if (tagId === 'custom_高级' || tags.find(t => t.id === tagId)?.label === '高级') {
      router.push('/premium');
      return;
    }
    setIsRecommendSelected(false);
    setSelectedTag(tagId);
  };

  return (
    <div className="animate-fade-in">
      {/* Content Type Toggle (Capsule Liquid Glass - Fixed & Centered) */}
      {!isTagManagementMode && !effectiveRecommendSelected && (
        <div className="mb-10 flex justify-center">
          <div className="relative w-80 p-1 bg-[var(--glass-bg)] border border-[var(--glass-border)] rounded-full grid grid-cols-2 backdrop-blur-2xl shadow-lg ring-1 ring-white/10 overflow-hidden">
            {/* Sliding Indicator */}
            <div
              className="absolute top-1 bottom-1 w-[calc(50%-4px)] bg-[var(--accent-color)] rounded-full transition-transform duration-400 cubic-bezier(0.4, 0, 0.2, 1) shadow-[0_0_15px_rgba(0,122,255,0.4)]"
              style={{
                transform: `translateX(${contentType === 'movie' ? '4px' : 'calc(100% + 4px)'})`,
              }}
            />

            <button
              onClick={() => setContentType('movie')}
              className={`relative z-10 py-2.5 text-sm font-bold transition-colors duration-300 cursor-pointer flex justify-center items-center ${contentType === 'movie' ? 'text-white' : 'text-[var(--text-color-secondary)] hover:text-[var(--text-color)]'
                }`}
            >
              电影
            </button>
            <button
              onClick={() => setContentType('tv')}
              className={`relative z-10 py-2.5 text-sm font-bold transition-colors duration-300 cursor-pointer flex justify-center items-center ${contentType === 'tv' ? 'text-white' : 'text-[var(--text-color-secondary)] hover:text-[var(--text-color)]'
                }`}
            >
              电视剧
            </button>
          </div>
        </div>
      )}

      <TagManager
        tags={tags}
        selectedTag={effectiveRecommendSelected ? '' : selectedTag}
        showTagManager={showTagManager}
        newTagInput={newTagInput}
        justAddedTag={justAddedTag}
        onTagSelect={handleRegularTagSelect}
        onTagDelete={handleDeleteTag}
        onToggleManager={() => setShowTagManager(!showTagManager)}
        onRestoreDefaults={handleRestoreDefaults}
        onNewTagInputChange={setNewTagInput}
        onAddTag={handleAddTag}
        onDragEnd={handleDragEnd}
        onJustAddedTagHandled={() => setJustAddedTag(false)}
        isLoadingTags={isLoadingTags}
        recommendTag={hasHistory ? {
          label: '为你推荐',
          isSelected: effectiveRecommendSelected,
          onSelect: handleRecommendSelect,
        } : undefined}
      />

      {/* overflow-x-clip：横向裁掉滑出容器的卡片，纵向不裁，避免旧层高度被切 */}
      {!isTagManagementMode && (
        <div className="relative overflow-x-clip">
          {/* 滑出层：切换前的卡片副本，动画结束后卸载 */}
          {outgoingCards && (
            <div
              aria-hidden="true"
              className={`pointer-events-none absolute inset-x-0 top-0 ${
                isEntering
                  ? outgoingCards.direction === 'forward'
                    ? 'kv-cards-exit-forward'
                    : 'kv-cards-exit-back'
                  : ''
              }`}
            >
              <MovieGrid
                movies={outgoingCards.movies}
                loading={false}
                hasMore={false}
                onMovieClick={handleMovieClick}
                prefetchRef={EMPTY_REF}
                loadMoreRef={EMPTY_REF}
              />
            </div>
          )}

          {/* 滑入层：新分类的数据到位后播放 */}
          <div className={enterClass}>
            {effectiveRecommendSelected ? (
              <MovieGrid
                movies={recommendMovies}
                loading={recommendLoading}
                hasMore={recommendHasMore}
                onMovieClick={handleMovieClick}
                prefetchRef={recommendPrefetchRef}
                loadMoreRef={recommendLoadMoreRef}
              />
            ) : (
              <MovieGrid
                movies={movies}
                loading={loading}
                hasMore={hasMore}
                onMovieClick={handleMovieClick}
                prefetchRef={prefetchRef}
                loadMoreRef={loadMoreRef}
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
}
