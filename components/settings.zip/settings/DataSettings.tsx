interface DataSettingsProps {
  onExport: () => void;
  onImport: () => void;
  onReset: () => void;
}

export function DataSettings({ onExport, onImport, onReset }: DataSettingsProps) {
  return (
    <section className="settings-panel bg-[var(--glass-bg)] border border-[var(--glass-border)] rounded-[var(--radius-2xl)] shadow-[var(--shadow-sm)]">
      <h2 className="settings-panel-title text-xl font-semibold text-[var(--text-color)]">数据管理</h2>
      <p className="mt-1 text-sm text-[var(--text-color-secondary)]">备份或恢复设置，也可以清除本地数据。</p>
      <div className="settings-data-list mt-5 overflow-hidden rounded-[var(--radius-2xl)] border border-[var(--glass-border)]">
        <button type="button" onClick={onExport} className="settings-data-action flex w-full items-center justify-between gap-4 border-b border-[var(--glass-border)] px-4 py-4 text-left text-[var(--text-color)] hover:bg-[var(--glass-hover)]">
          <span><strong className="block text-sm font-semibold">导出设置</strong><small className="mt-1 block text-xs leading-5 text-[var(--text-color-secondary)]">将设置与选定的历史记录保存为文件</small></span>
          <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" /></svg>
        </button>
        <button type="button" onClick={onImport} className="settings-data-action flex w-full items-center justify-between gap-4 border-b border-[var(--glass-border)] px-4 py-4 text-left text-[var(--text-color)] hover:bg-[var(--glass-hover)]">
          <span><strong className="block text-sm font-semibold">导入设置</strong><small className="mt-1 block text-xs leading-5 text-[var(--text-color-secondary)]">从文件或链接恢复设置</small></span>
          <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12" /></svg>
        </button>
        <button type="button" onClick={onReset} className="settings-data-action settings-data-danger flex w-full items-center justify-between gap-4 px-4 py-4 text-left text-red-600 dark:text-red-400 hover:bg-[var(--glass-hover)]">
          <span><strong className="block text-sm font-semibold">清除所有数据</strong><small className="mt-1 block text-xs leading-5 text-[var(--text-color-secondary)]">删除本地设置、历史记录和缓存</small></span>
          <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
        </button>
      </div>
    </section>
  );
}
