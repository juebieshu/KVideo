'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { Icon } from '@iconify/react';
import { clearSession, type AuthSession } from '@/lib/store/auth-store';
import { useAuthSession } from '@/lib/hooks/useAuthSession';
import './icons';

type LoginMode = 'none' | 'legacy_password' | 'managed';

function AccountCard({ children }: { children: ReactNode }) {
  return (
    <section className="settings-panel settings-account rounded-2xl border border-(--glass-border) bg-(--glass-bg) shadow-(--shadow-sm)">
      {children}
    </section>
  );
}

const ROLE_LABELS: Record<AuthSession['role'], string> = {
  super_admin: '超级管理员',
  admin: '管理员',
  viewer: '观众',
};

function loginModeLabel(mode: LoginMode): string {
  if (mode === 'managed') return '托管账户';
  if (mode === 'legacy_password') return '环境变量密码';
  return '未启用';
}

async function logoutAndReload() {
  try {
    await fetch('/api/auth/session', { method: 'DELETE' });
  } catch {
    // Best-effort logout: clear the local mirror even if the request fails.
  }

  clearSession();
  window.location.reload();
}

export function SettingsCurrentAccount() {
  const session = useAuthSession();
  const [loginMode, setLoginMode] = useState<LoginMode>('none');

  useEffect(() => {
    fetch('/api/auth')
      .then((response) => response.json())
      .then((data) => setLoginMode(data.loginMode || 'none'))
      .catch(() => setLoginMode('none'));
  }, []);

  if (!session) {
    return (
      <AccountCard>
        <div className="settings-empty-state flex items-start gap-3 rounded-[var(--radius-2xl)] border border-[var(--glass-border)] bg-[var(--sv2-surface-2)] p-4">
          <span className="settings-empty-icon flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px]"><Icon icon="lucide:user" width={20} /></span>
          <div>
            <p className="text-base font-semibold text-[var(--text-color)]">未启用账户登录</p>
            <p className="mt-1 text-sm text-[var(--text-color-secondary)]">
              当前部署使用本地模式，设置与观看数据保存在此浏览器中。
            </p>
          </div>
        </div>
      </AccountCard>
    );
  }

  return (
    <AccountCard>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[var(--sv2-accent-soft)] text-base font-semibold text-[var(--accent-color)]">
            {session.name.charAt(0)}
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-[var(--text-color)]">{session.name}</p>
            <p className="mt-0.5 text-sm text-[var(--text-color-secondary)]">
              {ROLE_LABELS[session.role]}
              {session.username ? ` · @${session.username}` : ''}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={logoutAndReload}
          className="inline-flex items-center gap-2 rounded-[var(--radius-2xl)] border border-[var(--glass-border)] bg-[var(--glass-bg)] px-3 py-2 text-sm font-medium text-[var(--text-color-secondary)] transition-colors hover:border-[var(--sv2-danger)] hover:text-[var(--sv2-danger)]"
        >
          <Icon icon="lucide:log-out" width={16} />
          退出登录
        </button>
      </div>

      <dl className="mt-5 divide-y divide-[var(--glass-border)] border-t border-[var(--glass-border)]">
        <div className="grid grid-cols-[96px_minmax(0,1fr)] gap-4 py-2.5 text-sm">
          <dt className="text-[var(--text-color-secondary)]">账户名</dt>
          <dd className="text-[var(--text-color)]">{session.name}</dd>
        </div>
        <div className="grid grid-cols-[96px_minmax(0,1fr)] gap-4 py-2.5 text-sm">
          <dt className="text-[var(--text-color-secondary)]">用户名</dt>
          <dd className="text-[var(--text-color)]">{session.username ? `@${session.username}` : '—'}</dd>
        </div>
        <div className="grid grid-cols-[96px_minmax(0,1fr)] gap-4 py-2.5 text-sm">
          <dt className="text-[var(--text-color-secondary)]">角色</dt>
          <dd className="text-[var(--text-color)]">{ROLE_LABELS[session.role]}</dd>
        </div>
        <div className="grid grid-cols-[96px_minmax(0,1fr)] gap-4 py-2.5 text-sm">
          <dt className="text-[var(--text-color-secondary)]">登录模式</dt>
          <dd className="text-[var(--text-color)]">{loginModeLabel(loginMode)}</dd>
        </div>
      </dl>
    </AccountCard>
  );
}
